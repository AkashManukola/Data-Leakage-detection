package com.com.model;

import com.com.helper.GetSetProperties;
import com.com.helper.SimpleCrypto;

public class UserModel {
    private String loginId = "";
    private String userPassword = "";
    private String userId = "";
    private String fName = "";
    private String lName = "";
    private String ipAddress = "";
    private String cellNumber = "";
    private String emailAddress = "";
    private String activeFlag = "";
    private String logStatus = "";
    private String logOnTime = "";
    private String logOffTime = "";
    private String rollId = "";
    private String days = "";
    private String city = "";
    private String pincode = "";

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        try {
            this.userPassword = SimpleCrypto.encrypt(GetSetProperties.getProperty("SEED_KEY"), userPassword);
        } catch (Exception ex) {
            ex.printStackTrace();
            // Handle the exception according to your needs
        }
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getFName() {
        return fName;
    }

    public void setFName(String fName) {
        this.fName = fName;
    }

    public String getLName() {
        return lName;
    }

    public void setLName(String lName) {
        this.lName = lName;
    }

    public String getIPAddress() {
        return ipAddress;
    }

    public void setIPAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    public String getCellNumber() {
        return cellNumber;
    }

    public void setCellNumber(String cellNumber) {
        this.cellNumber = cellNumber;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getActiveFlag() {
        return activeFlag;
    }

    public void setActiveFlag(String activeFlag) {
        this.activeFlag = activeFlag;
    }

    public String getLogStatus() {
        return logStatus;
    }

    public void setLogStatus(String logStatus) {
        this.logStatus = logStatus;
    }

    public String getLogOnTime() {
        return logOnTime;
    }

    public void setLogOnTime(String logOnTime) {
        this.logOnTime = logOnTime;
    }

    public String getLogOffTime() {
        return logOffTime;
    }

    public void setLogOffTime(String logOffTime) {
        this.logOffTime = logOffTime;
    }

    public String getRollId() {
        return rollId;
    }

    public void setRollId(String rollId) {
        this.rollId = rollId;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    public String getDays() {
        return days;
    }

    public void setDays(String days) {
        this.days = days;
    }
}
