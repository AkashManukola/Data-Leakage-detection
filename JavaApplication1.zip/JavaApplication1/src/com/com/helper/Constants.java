/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.com.helper;

/**
 *
 * @author Administrator
 */
public class Constants {

    public static final String DISTRIBUTOR_ROLL_ID="1";
    public static final String AGENT_ROLL_ID="2";
    public static final String ADMIN_ROLL_ID="3";



}
