/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.com.helper;

import com.com.model.UserModel;

/**
 *
 * @author Admin
 */
public class UserSession {
    public static UserModel loggedInUser;
}
